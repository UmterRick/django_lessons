from django.shortcuts import render

# Create your views here.
def main_page(request):
    msg = "Vladyslav"
    x = list(range(10))
    return render(request=request, template_name="index.html", context={"name": msg, "x": x})


